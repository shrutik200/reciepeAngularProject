export class ReceipeData {
    public id_number : number;
    public receipeName: any;
    public imageUrl: any;
    public description: any;
    public ingredients: Array<any>;
}
